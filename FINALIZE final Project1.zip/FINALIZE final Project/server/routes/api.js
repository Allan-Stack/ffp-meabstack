const express = require('express');
const router = express.Router();


 const mongoose = require('mongoose');
 const db = "mongodb+srv://user-allan:12345@mycluster.p5c6m.azure.mongodb.net/test";
 const User = require('../models/user');
 const PROdata = require('../models/PROdata')
//  const SEntry = require('../models/SEntrydata')
 const jwt = require('jsonwebtoken')

router.get('/',(req,res) =>{
    res.send('ni poda')
})
 

 mongoose.Promise = global.Promise;

mongoose.connect(db, function(err){
    if(err){
        console.error('error! ' + err)
    } else {
      console.log('Connected to mongodb')      
    }
});

function verifyToken(req, res, next) {
  if(!req.headers.authorization) {
    return res.status(401).send('Unauthorized request')
  }
  let token = req.headers.authorization.split(' ')[1]
  if(token === 'null') {
    return res.status(401).send('Unauthorized request')    
  }
  let payload = jwt.verify(token, 'secretKey')
  if(!payload) {
    return res.status(401).send('Unauthorized request')    
  }
  req.userId = payload.subject
  next()
}

router.get('/events', (req,res) => {
  let events = [
    {
      "_id": "1",
      "name": "TIKTOK",
      "description": "ENTETAINMENT APP",
    },
    {
      "_id": "2",
      "name": "UC BROWSER",
      "description": "BROWSING APP",
    },
    {
      "_id": "3",
      "name": "DUO RECORDER",
      "description": "RECORDING APP",
    },
    {
      "_id": "4",
      "name": "SHARE IT",
      "description": "DATA TRANSFERING APP",
    },
    {
      "_id": "5",
      "name": "LIKEE",
      "description": "ENTETAINMENT APP",
    },
    {
      "_id": "6",
      "name": "FREE FIRE",
      "description": "GAMING APP",
    }
  ]
  res.json(events)
})

router.get('/special',verifyToken,  (req, res) => {
  let specialEvents = [
    {
      "_id": "1",
      "name": "TIKTOK",
      "description": "ENTETAINMENT APP",
    },
    {
      "_id": "2",
      "name": "UC BROWSER",
      "description": "BROWSING APP",
    },
    {
      "_id": "3",
      "name": "DUO RECORDER",
      "description": "RECORDING APP",
    },
    {
      "_id": "4",
      "name": "SHARE IT",
      "description": "DATA TRANSFERING APP",
    },
    {
      "_id": "5",
      "name": "LIKEE",
      "description": "ENTETAINMENT APP",
    },
    {
      "_id": "6",
      "name": "FREE FIRE",
      "description": "GAMING APP",
    }
  ]
  res.json(specialEvents)
})

router.post('/register', (req, res) => {
  let userData = req.body
  let user = new User(userData)
  user.save((err, registeredUser) => {
    if (err) {
      console.log(err)      
    } else {
      let payload = {subject: registeredUser._id}
      let token = jwt.sign(payload, 'secretKey')
      res.status(200).send({token})
    // res.status(200).send(registeredUser)

    }
  })
})

router.post('/login', (req, res) => {
  let userData = req.body
  User.findOne({email: userData.email}, (err, user) => {
    if (err) {
      console.log(err)    
    } else {
      if (!user) {
        res.status(401).send('Invalid Email')
      } else 
      if ( user.password !== userData.password) {
        res.status(401).send('Invalid Password')
      } else {
        let payload = {subject: user._id}
        let token = jwt.sign(payload, 'secretKey')
        res.status(200).send({token})
        // res.status(200).send(user)
      }
    }
  })
})


router.get('/productlist',(req,res)=>{
    
  console.log("viewlist")

  PROdata.find().then((product)=>{res.send(product)});
 
});


router.post('/uplist',(req,res)=>{

  console.log("uplist")
  id=req.body.ID.id;
  console.log(id);
  PROdata.findById({_id:id}).then((product)=>{res.send(product)});

})



router.post('/insert',(req,res)=>{
  
  console.log("product added")
  console.log(req.body);  
  var product={

      
      productName:req.body.product.productName,
      productCode:req.body.product.productCode,
     
      starRating:req.body.product.starRating,
      imageUrl:req.body.product.imageUrl,
     
      description:req.body.product.description,

  }

  var product=new PROdata(product);
   product.save();
  // product.save().then(prods => res.json(prods));


});

router.post('/delete',(req,res)=>{
  console.log('delete');
  id=req.body.id;
  console.log(id)
  PROdata.findByIdAndDelete({_id:id}).then(()=>{console.log("Deleted Successfully");
  PROdata.find().then((product)=>{res.send(product);})})
})


router.post('/update',(req,res)=>{
  
  id=req.body.ID.id;
  console.log("update");
  console.log(id);
  
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods: GET, POST,PUT, PATCH, DELETE, OPTIONS");

  PROdata.findByIdAndUpdate({_id:id},{productId:req.body.product.productId,
      productName:req.body.product.productName,productCode:req.body.product.productCode,
      price:req.body.product.price,
      starRating:req.body.product.starRating,
      
      imageUrl:req.body.product.imageUrl,     
     
      description:req.body.product.description},(err,doc)=>{if(err)console.log(err)} )
  

 
  })

module.exports = router;