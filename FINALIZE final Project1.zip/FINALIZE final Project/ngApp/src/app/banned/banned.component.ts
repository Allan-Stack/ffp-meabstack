import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'

@Component({
  selector: 'app-banned',
  templateUrl: './banned.component.html',
  styleUrls: ['./banned.component.css']
})
export class BannedComponent implements OnInit {

  constructor( private _router: Router) { }

  ngOnInit() {
  }
  goToPage(pageName:string):void{
    this._router.navigate([`${pageName}`])
  }
}
