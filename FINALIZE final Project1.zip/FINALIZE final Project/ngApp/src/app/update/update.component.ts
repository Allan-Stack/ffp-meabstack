import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';
import{ProductModel} from '../productlist/product.model';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  constructor(private productService:ProductService , private router :Router,private _route:ActivatedRoute) { }
  UpItem= new ProductModel(null,null,null,null,null,null,null,null);
  

  ngOnInit(): void {
    let id=this._route.snapshot.paramMap.get("id")
    const ID={id:id};
    
    this.productService.Upget(ID)
    .subscribe((data)=>{this.UpItem=JSON.parse(JSON.stringify(data)); })
    
   
  }
  UProduct(){

    let id=this._route.snapshot.paramMap.get("id")
    const ID={id:id};
    this.productService.UpProduct(ID,this.UpItem)
    
    alert('Successfully updated');
    this.router.navigate(['/productlist'])
  }

 

}
