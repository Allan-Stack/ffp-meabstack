import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http:HttpClient) { }
getProducts()
{
  return this.http.get("http://localhost:3000/api/productlist")

  
}

newproduct(item){
 
  return this.http.post("http://localhost:3000/api/insert",{"product":item})
  .subscribe(data=>{console.log(data)})
 
}

deletePro(_id){return this.http.post("http://localhost:3000/api/delete",{"id":_id})}


UpProduct(ID,UpItem){

  return this.http.post("http://localhost:3000/api/update",{"product":UpItem,"ID":ID})
  .subscribe((data)=>{console.log(data)})
  
 }

Upget(ID){
  
  console.log(ID)
  return this.http.post("http://localhost:3000/api/uplist",{"ID":ID})
  
}

}
