 import { AuthGuard } from './auth.guard';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { ReactiveFormsModule  } from '@angular/forms';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { EventsComponent } from './events/events.component';
import { SpecialEventsComponent } from './special-events/special-events.component';
 import { AuthService } from './auth.service';
 import { EventService } from './event.service';
 import { TokenInterceptorService } from './token-interceptor.service';
import { ProductlistComponent } from './productlist/productlist.component';
//  import { HeaderComponent } from './suggest/header.component';
import { NewproductComponent } from './newproduct/newproduct.component';
import { UpdateComponent } from './update/update.component';
import { HeaderComponent } from './header/header.component';
import { TiktokComponent } from './tiktok/tiktok.component';
import { UcbrowserComponent } from './ucbrowser/ucbrowser.component';
import { DuorecordComponent } from './duorecord/duorecord.component';
import { ShareitComponent } from './shareit/shareit.component';
import { LikeeComponent } from './likee/likee.component';
import { FreefireComponent } from './freefire/freefire.component';
import { BannedComponent } from './banned/banned.component';



// import { BlogComponent } from './blog/blog.component';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    EventsComponent,
    SpecialEventsComponent,
    ProductlistComponent,
    
    NewproductComponent,
    UpdateComponent,
    HeaderComponent,
    TiktokComponent,
    UcbrowserComponent,
    DuorecordComponent,
    ShareitComponent,
    LikeeComponent,
    FreefireComponent,
    BannedComponent,
    // ReactiveFormsModule,
    // BlogComponent,
    

  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  // providers: [AuthService, AuthGuard, EventService],
  providers: [AuthService, AuthGuard, EventService, 
  {
    provide: HTTP_INTERCEPTORS,
    useClass: TokenInterceptorService,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }