import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component'
import { RegisterComponent } from './register/register.component'
import { EventsComponent } from './events/events.component';
import { SpecialEventsComponent } from './special-events/special-events.component';
 import { AuthGuard } from './auth.guard';
import { UpdateComponent } from './update/update.component';
import { ProductlistComponent } from './productlist/productlist.component';
import { NewproductComponent } from './newproduct/newproduct.component';
// import {SuggestsComponent} from './suggests.component';
import { TiktokComponent } from './tiktok/tiktok.component';
import { UcbrowserComponent } from './ucbrowser/ucbrowser.component';
import { DuorecordComponent } from './duorecord/duorecord.component';
import { ShareitComponent } from './shareit/shareit.component';
import { LikeeComponent } from './likee/likee.component';
import { FreefireComponent } from './freefire/freefire.component';
import { BannedComponent } from './banned/banned.component';




const routes: Routes = [
  {
    path: '',
    redirectTo: '/events',
    pathMatch: 'full'
  },
  
  {
    path: 'banned',
    component: BannedComponent
  },
  {
    path: 'ucbrowser',
    component: UcbrowserComponent
  },
  {
    path: 'duorecord',
    component: DuorecordComponent
  },
  {
    path: 'shareit',
    component: ShareitComponent
  },{
    path: 'freefire',
    component: FreefireComponent
  },
  {
    path: 'tiktok',
    component: TiktokComponent
  },{
    path: 'likee',
    component: LikeeComponent
  },
  {
    path: 'events',
    component: EventsComponent
  },
  {
     path: 'update/:id',
     component: UpdateComponent
  },
  {path:'productlist',component:ProductlistComponent,canActivate:[AuthGuard]},
{path:'newproduct',component:NewproductComponent,canActivate:[AuthGuard]},
// {path:'update/:id',component:UpdateComponent}];

  {
    path: 'special',
     canActivate: [AuthGuard],
    component: SpecialEventsComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'register',
    component: RegisterComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }